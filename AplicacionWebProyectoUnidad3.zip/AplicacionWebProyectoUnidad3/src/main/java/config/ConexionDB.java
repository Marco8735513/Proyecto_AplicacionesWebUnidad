package config;


import java.sql.Connection;
import java.sql.DriverManager;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author marco
 */
public class ConexionDB {
   
     private static final String URL = "jdbc:sqlserver://MARCO\\SQLEXPRESS:1433;databaseName=FlixVana;encrypt=false;";
    private static final String USER = "marco_savlg";
    private static final String PASSWORD = "1234";

    public static Connection getConnection() {
        Connection conn = null;
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            conn = DriverManager.getConnection(URL, USER, PASSWORD); // no cast necesario
            System.out.println("✅ Conexión exitosa a SQL Server");
        } catch (Exception e) {
            System.out.println("❌ Error al conectar con la base de datos");
            e.printStackTrace();
        }
        return conn;
    }
    
}
