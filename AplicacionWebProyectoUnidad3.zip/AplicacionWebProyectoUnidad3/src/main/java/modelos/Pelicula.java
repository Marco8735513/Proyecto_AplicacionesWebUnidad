/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

/**
 *
 * @author marco
 */
public class Pelicula {

    private String title;
    private String year;
    private String image;
    private String description;

    public Pelicula(String title, String year, String image, String description) {
        this.title = title;
        this.year = year;
        this.image = image;
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public String getYear() {
        return year;
    }

    public String getImage() {
        return image;
    }

    public String getDescription() {
        return description;
    }
}
